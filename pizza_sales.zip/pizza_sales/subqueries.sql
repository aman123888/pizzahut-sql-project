-- Which pizza type generated the highest total revenue?

SELECT pt.name
FROM pizzahut.pizza_types pt
WHERE pt.pizza_type_id = (
    SELECT p.pizza_type_id
    FROM pizzahut.pizzas p
    JOIN pizzahut.order_details od ON p.pizza_id = od.pizza_id
    GROUP BY p.pizza_type_id
    ORDER BY SUM(od.quantity * p.price) DESC
    LIMIT 1
);

-- Which orders contain only one type of pizza?

SELECT order_id
FROM pizzahut.order_details
GROUP BY order_id
HAVING COUNT(DISTINCT pizza_id) = 1;
