-- Index for faster lookup on pizza types (for filtering by name)

CREATE INDEX idx_pizza_types_name ON pizzahut.pizza_types(name(50));

-- How many times was the pizza named 'bbq_ckn' ordered?

SELECT SUM(od.quantity)
FROM pizzahut.order_details od
JOIN pizzahut.pizzas p ON od.pizza_id = p.pizza_id
JOIN pizzahut.pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
WHERE pt.name = 'bbq_ckn';

-- Index on order_date for time-based analysis

CREATE INDEX idx_orders_order_date ON pizzahut.orders(order_date);

-- What is the total number of pizzas sold in January 2015?

SELECT SUM(od.quantity)
FROM pizzahut.order_details od
JOIN pizzahut.orders o ON od.order_id = o.order_id
WHERE o.order_date BETWEEN '2015-01-01' AND '2015-01-31';





