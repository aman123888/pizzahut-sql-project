create database pizzahut;
show databases;

create table orders(
order_id int not null,
order_date date not null,
order_time time not null,
primary key(order_id));