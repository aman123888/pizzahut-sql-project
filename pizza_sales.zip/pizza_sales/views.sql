-- What is the total revenue generated per pizza type?

CREATE VIEW v_total_revenue_per_pizza_type AS
SELECT 
    pt.name AS pizza_name,
    SUM(od.quantity * p.price) AS total_revenue
FROM 
    pizzahut.order_details od
JOIN 
    pizzahut.pizzas p ON od.pizza_id = p.pizza_id
JOIN 
    pizzahut.pizza_types pt ON p.pizza_type_id = pt.pizza_type_id
GROUP BY 
    pt.name;
    
    -- What is the total number of pizzas sold per day?
    
    CREATE VIEW v_daily_sales AS
SELECT 
    o.order_date,
    SUM(od.quantity) AS total_pizzas_sold
FROM 
    pizzahut.orders o
JOIN 
    pizzahut.order_details od ON o.order_id = od.order_id
GROUP BY 
    o.order_date;

